<?php
define("SERVERPATH", "https://node02.filocity.com/rest/");
?>