<?php 
include ('ErrorHandling.php');
try{


if($_SERVER['HTTPS'] == "")
	header("Location:https://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']);

$shareId = "0";

if(isset($_REQUEST['share'])) {
        $shareId = $_REQUEST['share'];
    }


include('pdf.php');

$tmpidarr=explode(',',$_REQUEST['id']);

$uploads_dir_swf="swf";

$datadir = "pdf/";

$uploads_dir = "pdf";
$outputName = $datadir.$_REQUEST['filename'].".pdf";

$cmd = "gs -q -sPAPERSIZE=letter -dNOPAUSE -dBATCH -sDEVICE=pdfwrite -sOutputFile='$outputName' ";

$actPages = 1;

$fileArray= array();

for($i=0;$i<count($tmpidarr);$i++)
{
	$url = SERVERPATH."get/secret/".$_REQUEST['secret']."/share/".$shareId."/space/".$_REQUEST['space']."/document/".$tmpidarr[$i];
	$image = file_get_contents($url);

	$docname=$tmpidarr[$i];

	$tmpvar=$http_response_header[3];
	$tmparr=explode("=",$tmpvar);
	$extarr=explode('.',$tmparr[1]);
	$ext=substr($extarr[1], 0, -1);
 //$outputName = preg_replace('|[^a-zA-Z0-9_\-.]|', '%20', $outputName);
//echo $outputName;
	file_put_contents("pdf/".$docname.'.'.$ext, $image);

	$name = $docname.'.'.$ext;//str_replace(" ","_",$_FILES['Filedata']['name']);

	error_log($name, 0);

	list($swf_file, $ext) = explode(".",$name);

	$swf_name  = $swf_file;

	$tmp_name =$name;//$_FILES['Filedata']['tmp_name'];

	//move_uploaded_file($tmp_name, "$uploads_dir/$name");
	//if pdf
	$bookmark_name = str_replace("\"", "", $extarr[0]);

	if($ext=='pdf'){
		move_uploaded_file($tmp_name, "$uploads_dir/$name");
	}else{
		include('anyTopdf.php');
	}

	$fileArray[$i] = "pdf/".$tmpidarr[$i].".pdf";
	$cmd .= " -c \"[/Page $actPages /View [/XYZ null null null] /Title ($bookmark_name) /OUT pdfmark\"";
	$totalPages = (int) shell_exec("pdfinfo '$fileArray[$i]' | awk '/Pages/ {print $2}'");
	$actPages = $actPages + $totalPages;

}

$cmd .= " -f ";
//Add each pdf file to the end of the command

foreach($fileArray as $file) {
    $cmd .= $file." ";
}

$result = shell_exec($cmd);


//To upload the file to server from another server

	$file=getcwd().'/'.$outputName;


    $ch = curl_init(SERVERPATH.'save/secret/'.$_REQUEST['secret']."/share/".$_REQUEST['share'].'/space/'.$_REQUEST['space'].'/folder/'.$_REQUEST['folder']); 
    curl_setopt($ch, CURLOPT_POSTFIELDS, array('file'=>"@$file",'testkey'=>'test value'));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $postResult = curl_exec($ch);
    curl_close($ch);

    $postResult; 
//end

for($i=0;$i<count($fileArray);$i++)
{
	if(file_exists($fileArray[$i]))
		unlink($fileArray[$i]);
}
function json_code ($json) { 

      //remove curly brackets to beware from regex errors

      $json = substr($json, strpos($json,'{')+1, strlen($json));
      $json = substr($json, 0, strrpos($json,'}'));
      $json = preg_replace('/(^|,)([\\s\\t]*)([^:]*) (([\\s\\t]*)):(([\\s\\t]*))/s', '$1"$3"$4:', trim($json));

      return json_decode('{'.$json.'}', true);
   }  

$jarr = json_code($postResult);

if($jarr['status']=='OKAY')
{
	$newId=$jarr['result']['documentId'];
	$totalPages = shell_exec("pdfinfo '$outputName' | awk '/Pages/ {print $2}'");
	$numPages = intval($totalPages);
	
	shell_exec("pdf2swf -v -t -T 9 '$outputName' -o '$uploads_dir_swf/$newId%.swf'");
	if(file_exists($outputName))
	unlink($outputName);

	$arr = array('status' => 'OKAY', 'fileId' => $newId);

	$jsontext = json_encode($arr);

//.":".$numPages.",".$newId
	echo $jsontext;
}
else
{
	$arr = array('status' => 'FAILED');

	$jsontext = json_encode($arr);

	echo $jsontext;
	throw(new Exception('not upload file successfully', 1));

}
}catch(Exception $e){
	userErrorHandler("101", $e->getMessage(), "sendMultipleId.php",$e->getLine(), "");
	$arr = array('status' => 'FAILED');

	$jsontext = json_encode($arr);

	echo $jsontext;
}
?>