<?php 


//if($_SERVER['HTTPS'] == "")
	//header("Location:https://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']);

if(empty($_REQUEST['id']) || empty($_REQUEST['secret']) || empty($_REQUEST['space']) ){
throw(new Exception('Invalid Request Data', 1));
//echo "the error message you want ".$_REQUEST['share'];
die;
}

include('pdf.php');
 $url = SERVERPATH."get/secret/".$_REQUEST['secret']."/share/".$_REQUEST['share']."/space/".$_REQUEST['space']."/document/".$_REQUEST['id'];

 $image = file_get_contents($url);

$docname=$_REQUEST['id'];

$tmpvar=$http_response_header[3];

/*
$ext1 =  substr(strrchr($fileName,'.'),1);
$fname =  substr($fileName,0,strrpos($fileName,'.'));
  
$pdf_name = $fname.".pdf";
$swf_name = $fname;
*/

$tmparr=explode("=",$tmpvar);

$filen = $tmparr[1];
$filen = str_replace('"', "", $filen);

//$extarr=explode('.',$tmparr[1]);
$ext =  substr(strrchr($filen,'.'),1);

$fname =  substr($filen,0,strrpos($filen,'.'));
  
$pdf_name = $fname.".pdf";
$swf_name = $fname;


//print_r($extarr);
 //$ext=substr($extarr[1], 0, -1);
 

file_put_contents("pdf/".$docname.'.'.$ext, $image);

$uploads_dir = "pdf";
$uploads_dir_swf = "swf";
 $name = $docname.'.'.$ext;

 error_log($name, 0);

 //list($swf_file, $ext) = explode(".",$name);

// $swf_name  = $swf_file;

 $tmp_name =$name;//$_FILES['Filedata']['tmp_name'];

 //move_uploaded_file($tmp_name, "$uploads_dir/$name");
 //if pdf

  
 if($ext=='pdf'){
  
  $totalPages = shell_exec("pdfinfo '$uploads_dir/$name' | awk '/Pages/ {print $2}'");
  $numPages = intval($totalPages);
    shell_exec("pdf2swf -v -t -T 9 '$uploads_dir/$name' -o '$uploads_dir_swf/$swf_name%.swf'");
 
 }else{
  include('anyTopdf.php');
	 $totalPages = shell_exec("pdfinfo '$uploads_dir/$pdf_name' | awk '/Pages/ {print $2}'");
	$numPages = intval($totalPages);
	shell_exec("pdf2swf -v -t -T 9 '$uploads_dir/$pdf_name' -o '$uploads_dir_swf/$swf_name%.swf'");
 
 }
echo $numPages.",".$swf_name;
if(file_exists("pdf/".$name))
	unlink("pdf/".$name)

?>

