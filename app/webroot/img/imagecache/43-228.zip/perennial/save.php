<?php
if($_SERVER['HTTPS'] == "")
	header("Location:https://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']);

include('pdf.php');
if ( isset ( $GLOBALS["HTTP_RAW_POST_DATA"] )) {
	
	header('Content-type: application/pdf');
	header('Content-disposition: attachment; filename='.$_REQUEST['name']);

		$fp = fopen( 'pdf/'.$_REQUEST['name'], 'wb' );
       fwrite( $fp, $GLOBALS['HTTP_RAW_POST_DATA' ] );
       fclose( $fp);
		
	}else{
		//echo "error1 ".$_REQUEST['name'];
		throw(new Exception('Problem Saving PDF', 1));
		//echo "the error message you want";
	die;
}

$uploadDirectory = "pdf/";
$uploads_dir=$uploadDirectory;

$filename=$uploadDirectory.$_REQUEST['name'];
 $file=getcwd().'/'.$filename;

 
    
    $ch = curl_init(SERVERPATH.'save/secret/'.$_REQUEST['secret']."/share/".$_REQUEST['share'].'/space/'.$_REQUEST['space'].'/folder/'.$_REQUEST['folder']);  
    curl_setopt($ch, CURLOPT_POSTFIELDS, array('file'=>"@$file",'testkey'=>'test value'));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $postResult = curl_exec($ch);
	//echo $postResult;
    curl_close($ch);

     $postResult; 


function json_code ($json) { 

      //remove curly brackets to beware from regex errors

      $json = substr($json, strpos($json,'{')+1, strlen($json));
      $json = substr($json, 0, strrpos($json,'}'));
      $json = preg_replace('/(^|,)([\\s\\t]*)([^:]*) (([\\s\\t]*)):(([\\s\\t]*))/s', '$1"$3"$4:', trim($json));

      return json_decode('{'.$json.'}', true);
   }  

$jarr = json_code($postResult);

if($jarr['status']=='OKAY')
{
//echo "OKAY";
    $newId=$jarr['result']['documentId'];
  	$totalPages = shell_exec("pdfinfo '$filename' | awk '/Pages/ {print $2}'");
   $numPages = intval($totalPages);
   $tmpvar=$_REQUEST['folder'].".pdf";
  shell_exec("pdf2swf -v -t -T 9 '$uploads_dir/$tmpvar' -o '$uploads_dir_swf/$newId%.swf'");
   unlink("pdf/".$outputName);
  echo $numPages.",".$newId;

	  
}
else
{
	 throw(new Exception('not upload file successfully', 1));
	//echo "the error message you want";
	die;
}

//echo $GLOBALS["HTTP_RAW_POST_DATA"];
unlink("pdf/".$_REQUEST['name']);
?>