<?php
include ('ErrorHandling.php');
try{
//if($_SERVER['HTTPS'] == "")
//	header("Location:https://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']);
//echo "1";
//die;

$tempFile = $_FILES['Filedata']['tmp_name'];
$fileName = $_REQUEST['name'];
$fileSize = $_FILES['Filedata']['size'];

	//header('Content-type: application/pdf');
	//header('Content-disposition: attachment; filename='.$fileName);

	//$fp = fopen( 'pdf/'.$fileName, 'wb' );
//       fwrite( $fp, $GLOBALS['HTTP_RAW_POST_DATA' ] );
  //     fclose( $fp);


$uploadDirectory = "pdf/";
$uploads_dir=$uploadDirectory;
$uploads_dir_swf = "swf/";

$filename=$uploadDirectory.$fileName;
move_uploaded_file($tempFile, $filename);


//echo "OKAY";
  // $newId=$jarr['result']['documentId'];
   //$tmpvar=$_REQUEST['folder'].".pdf";
   
   $ext1 =  substr(strrchr($fileName,'.'),1);
   $fname =  substr($fileName,0,strrpos($fileName,'.'));
   //echo $myname;
   //echo $ext1;
   //list($swf_file, $ext)  = explode(".",$fileName );
   
   $pdf_name = $fname.".pdf";
   $swf_name = $fname;
   $numPages =0;

   if($ext1=='pdf'){
         $totalPages = shell_exec("pdfinfo '$uploads_dir/$pdf_name' | awk '/Pages/ {print $2}'");
         $numPages = intval($totalPages);
	  shell_exec("pdf2swf -v -t -T 9 '$uploads_dir/$pdf_name' -o '$uploads_dir_swf/$swf_name%.swf'");
    }else{
		exec("python ../PyODConverter.py '$uploads_dir/$fileName' '$uploads_dir/$pdf_name'");
		move_uploaded_file($fileName, "$uploads_dir/$pdf_name");

		$totalPages = shell_exec("pdfinfo '$uploads_dir/$pdf_name' | awk '/Pages/ {print $2}'");
		$numPages = intval($totalPages);

     	shell_exec("pdf2swf -v -t -T 9 '$uploads_dir/$pdf_name' -o '$uploads_dir_swf/$swf_name%.swf'");
   }
 echo $numPages.",".$fname;


}catch(Exception $e){
	userErrorHandler("upload", $e->getMessage(), "upload.php",$e->getLine(), "");
}
//unlink("pdf/".$fileName)
?>