<?php
list($swf_file, $ext)  = explode(".",$name);
   $pdf_name = $swf_file.".pdf";
   $swf_name1 = $swf_file;

   exec("python ../PyODConverter.py '$uploads_dir/$name'  '$uploads_dir/$pdf_name'");
   
   move_uploaded_file($tmp_name, "$uploads_dir/$pdf_name");
   $totalPages = shell_exec("pdfinfo '$uploads_dir/$pdf_name' | awk '/Pages/ {print $2}'");
   $numPages = intval($totalPages);

	if(file_exists("pdf/".$name))
     unlink("pdf/".$name);

?>